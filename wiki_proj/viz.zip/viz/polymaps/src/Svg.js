po.svg = function(type) {
  return document.createElementNS(po.ns.svg, type);
};
