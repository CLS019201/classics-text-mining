if (!org) var org = {};
if (!org.polymaps) org.polymaps = {};
(function(po){

  po.version = "2.5.1"; // semver.org

  var zero = {x: 0, y: 0};
